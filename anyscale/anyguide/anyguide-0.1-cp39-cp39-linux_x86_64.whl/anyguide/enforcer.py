from collections import deque
from typing import (FrozenSet, List, Optional, cast, Union, Tuple, Set,
                    Hashable)
import os
import numpy as np
from cachetools import LRUCache

from transformers import AutoTokenizer, PreTrainedTokenizerBase

from anyguide_cpp import Element, Stack, Trie, Enforcer, PrefixCache
from .parser import Grammar
from .trie import TokenizerTrie
# from .cache import PrefixCache

# 2 ** 10
MAX_GRAMMAR_ENFORCER_LOCAL_CACHE_SIZE = int(
    os.environ.get("MAX_GRAMMAR_ENFORCER_LOCAL_CACHE_SIZE", 1 << 10))
# 2 ** 16
MAX_GRAMMAR_ENFORCER_ADVANCE_CACHE_SIZE = int(
    os.environ.get("MAX_GRAMMAR_ENFORCER_ADVANCE_CACHE_SIZE", 1 << 16))

LocalCacheKeyType = FrozenSet[Stack]
AdvanceStackCacheKeyType = Tuple[Tuple[Element, ...], Stack, bool]


class GrammarEnforcer:
    """Enforces the grammar on the input tokens.

    Args:
        grammar: The grammar object that captures the rules that we want to
            enforce.
        tokenizer_trie: To avoid creating the tokenizer trie each time we
            create a grammar, you can create it outside and pass it in, so it
            gets reused.
        global_stack_prefix_cache: A dictionary that maps stack prefixes to
            token masks. This is useful for handling common special cases that
            require a big trie walk but you want to shorcut it, by matching a
            stack-prefix that you know the token masks for. This can speed up
            json mode decoding significantly (for cases where the rule is to
            decode a string)
    """

    def __init__(
        self,
        grammar: Grammar,
        tokenizer_trie: TokenizerTrie,
        global_stack_prefix_cache: Optional["PrefixCache"] = None,
    ) -> None:
        self.grammar = grammar
        self._enforcer = Enforcer()

        # stacks holds the state of the enforcer.
        # Each item in the stack counts for one possible stack of rule elements
        # that can be matched. It implemented as a Set to avoid duplicates.
        self.stacks: Set[Stack] = set()
        self.tokenizer_trie = tokenizer_trie

        # Global cache passed in externally:
        # Should be a mapping from stack prefixes to token masks.
        # If a given stack prefix is found in the stack at any time, we return
        # the token mask corresponding to that prefix without doing a trie walk.
        self.global_stack_prefix_cache = (global_stack_prefix_cache
                                          or PrefixCache())
        # Local cache from stacks to token_mask:
        # If during multi-step generation, we find ourselves in the same state
        # as given by the stacks we can return the token mask directly. There
        # are many schemas that for many steps, the state remains idempotent,
        # meaning that the stack remains the same even after accepting many
        # tokens. In these cases you won't need to calculate anything.
        # In this cache, keys are tuples of stacks and values are token masks.
        self._local_stack_cache: LRUCache[LocalCacheKeyType, np.ndarray] = (
            LRUCache(MAX_GRAMMAR_ENFORCER_LOCAL_CACHE_SIZE))
        # Cache for advance_stack:
        # The keys in this cache are tuple of elements in the rule and the
        # input_stack. If the schema has this property that many rules
        # reference essentially the same rule (for example there are a lot of
        # rules that reference string), then this cache can be useful. In these
        # scenarios, the rule that we are adding will be, for example,
        # `string`, and if the input_stack is also the same, we can return the
        # updated stack values without having to go through the recursion.
        self._advance_stack_cache: LRUCache[Hashable, Set[Stack]] = (
            LRUCache(MAX_GRAMMAR_ENFORCER_ADVANCE_CACHE_SIZE))

        self._initialized = False

    @classmethod
    def from_hf_tokenizer(
        cls,
        grammar: Grammar,
        tokenizer: Union[PreTrainedTokenizerBase, str],
        global_stack_prefix_cache: Optional["PrefixCache"] = None,
    ) -> "GrammarEnforcer":
        """Creates a GrammarEnforcer from a grammar and an hf tokenizer object.
        """

        if isinstance(tokenizer, str):
            tokenizer = AutoTokenizer.from_pretrained(tokenizer)
            tokenizer = cast(PreTrainedTokenizerBase, tokenizer)

        tokenizer_trie = TokenizerTrie(tokenizer)
        return cls(grammar, tokenizer_trie, global_stack_prefix_cache)

    def init(self, stacks: Optional[List[Stack]] = None) -> None:
        """Initializes the state of the stack set.

        You can either initialize the state of the enforcer via an external
        stack (used for testing) or via the grammar.

        Args:
            stacks: The initial state of the stack set. If None, the
                initial state is set to the start rule of the grammar.
        """
        start_rule_name = self.grammar.start_rule_name
        start_rule = self.grammar.rules[start_rule_name]

        if stacks is not None:
            self.stacks = set(stacks)
        else:
            # When initialized we don't resolve the reference rules to get
            # cache hit with the common prefixes
            self.stacks = self.advance_stack(rule=start_rule,
                                             rule_name=start_rule_name,
                                             resolve_references=False)
        self._initialized = True

    def is_initialized(self) -> bool:
        return self._initialized

    def _raise_error_if_not_initialized(self, method_name: str) -> None:
        if not self.is_initialized():
            raise ValueError(
                "EnforcerState needs to be initialized before calling "
                f"this .{method_name}. Hint: call `init()` method.")

    def _accept_char(self, char: str, update_stack: bool = False) -> bool:
        """Checks if a character can be matched to the current state.

        This method changes the internal state of the enforcer if the character
        is matched and `update_stack` is true. If `update_stack` is False, it
        will just check if the character can be matched.

        Args:
            char: The character to be matched.
            update_stack: If True, the internal state of the enforcer will be
                updated if the character is matched, otherwise it will just not
                change the state of the enforcer.
        Returns:
            True if the character is matched. If False is returned,
            the state is not updated.
        """
        is_matched = False
        new_stacks: Set[Stack] = set()

        queue = deque(self.stacks)
        while queue:
            stack = queue.popleft()
            top_element = stack.top()
            if top_element is not None:
                if top_element.is_rule_ref():
                    stacks = self.advance_stack(stack=stack)
                    queue.extend(stacks)
                elif top_element.is_match(ord(char)):
                    is_matched = True
                    if not update_stack:
                        return is_matched
                    new_stack = cast(Stack, stack[1:])
                    # DO NOT expand the references within this stack to
                    # maximize cache hits for the next step of get_token_masks
                    new_stack_set = self.advance_stack(
                        stack=new_stack, resolve_references=False)
                    new_stacks.update(new_stack_set)

        if update_stack and is_matched:
            self.stacks = new_stacks

        return is_matched

    def accept_char(self, char: str) -> bool:
        """Checks if a char can be matched to the current state.

        NOTE: This method updates the state only if the character is accepted.
        """
        self._raise_error_if_not_initialized("accept_char")
        return self._accept_char(char, update_stack=True)

    def accept_token(self, token_id: int) -> bool:
        """Checks if a token can be matched to the current state.

        NOTE: This method changes the internal state of the enforcer, whether
        the token is fully accepted or partially accepted.

        NOTE: In LLM tokenizers, a given token may be very similar to the token
        that should be matched, but still it does not get matched. For example,
        the token `▁{"` has a space in front, but the grammar rule dictates
        `{"` as the start of the string. In other words, you cannot always
        take a response that looks like it is a match, tokenize it and expect
        it to be matched by the grammar. In that case you should match only by
        characters as going through tokenizer may give you incorrect answers.
        """
        self._raise_error_if_not_initialized("accept_token")

        # Always accept EOS token regardless of the current state.
        # If we do not do this, then in case of ignore_eos=True,
        # the enforcer will not accept the EOS token and will cause
        # failure in the logit processor
        if token_id == self.tokenizer_trie.eos_token_id:
            return True

        for c in self.tokenizer_trie.id2str(token_id):
            if not self.accept_char(c):
                return False
        return True

    def advance_stack(self,
                      *,
                      rule: Optional[List[Element]] = None,
                      stack: Optional[Stack] = None,
                      rule_name: str = "",
                      resolve_references: bool = True) -> Set[Stack]:
        """Implements caching at advance_stack level."""
        rule = rule or []
        if stack is None:
            stack = Stack()

        updated_stacks = self._enforcer.advance_stack(
            rule=rule, stack=stack, rule_name=rule_name, resolve_references=resolve_references, rules=self.grammar.rules)
        return updated_stacks

    def get_tokens_mask(self) -> np.ndarray:
        """Returns a mask over allowed tokens, given the current state.

        Output is a numpy array of shape (num_vocab,) where true indicates
        allowed tokens.

        NOTE: This method does not update the state. To update the state, use
        `accept_token`.

        Returns:
            A numpy array of shape (num_vocab,) where true indicates allowed
            tokens.
        """
        self._raise_error_if_not_initialized("get_tokens_mask")

        cache_key = frozenset(self.stacks)
        if cache_key in self._local_stack_cache:
            return self._local_stack_cache[cache_key]

        # Using numpy is more efficient than lists or torch tensors.
        token_mask = np.zeros(self.tokenizer_trie.vocab_size, dtype=np.bool_)

        for stack in self.stacks:

            self.walk_trie(self.tokenizer_trie,
                           stack,
                           token_mask,
                           cache=self.global_stack_prefix_cache)

        if not np.any(token_mask):
            # If there is no option, we should unmask eos token
            token_mask[self.tokenizer_trie.eos_token_id] = True

        self._local_stack_cache[cache_key] = token_mask
        return token_mask

    def walk_trie(
        self,
        trie: Trie,
        stack: Stack,
        mask: np.ndarray,
        cache: Optional["PrefixCache"] = None,
    ) -> List[Trie]:
        """Iterative function to walk the trie and update the mask.

        This method, given a stack of rule elements, walks the tokenizer trie,
        character by character, and checks if the character can be accepted by
        the top element of the stack. If so it updates the stack and checks the
        next character, and so on. During this iterative process when the
        traversal encounters a token_id where all the corresponding characters
        are accepted by the stack, it updates the mask array to accept that
        token_id.

        Args:
            trie: The trie to be walked.
            stack: The stack of rule elements. This is the initial state at the
                root of the trie.
            mask: The mask array that is updated to accept the token_ids that
                are valid for the given stack. This is updated in-place.
            cache: Optional external cache to store the prefix of stacks and
                the tries.
        Returns:
            A list of prefix trees that are not explored due to reaching the
            end of the stack. This list is used as the values of the cache so
            that when we get a stack prefix match we can resume the state of
            trie walk from the latest point.

            Also the mask is updated in-place.
        """

        cache = cache or PrefixCache()
        # if cache is None:
        #     cache = PrefixCache()
        
        unexplored_tries = self._enforcer.walk_trie(
            trie=trie, 
            stack=stack, 
            mask=mask, 
            rules=self.grammar.rules, 
            prefix_cache=cache
        )

        # cache_key = (stack, trie)
        # if cache and cache_key in cache:
        #     cached_mask, cached_tries = cache[cache_key]
        #     if cached_mask is not None:
        #         mask |= cached_mask

        #         stack_prefix = cache.get_matched_stack_prefix(stack)
        #         remaining_stack = cast(Stack, stack[stack_prefix.size():])
        #         if cached_tries:
        #             trie_stack_pairs = [(trie, remaining_stack) for trie in cached_tries]
        # else:
        #     trie_stack_pairs = [(trie, stack)]

        # unexplored_tries = []
        # for cur_trie, cur_stack in trie_stack_pairs:
        #     unexplored_tries.extend(self._enforcer.walk_trie(trie=cur_trie, stack=cur_stack, mask=mask, rules=self.grammar.rules))
        return unexplored_tries