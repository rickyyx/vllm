from typing import Dict, Optional

from transformers import PreTrainedTokenizerBase
from anyguide_cpp import Trie


class TokenizerTrie(Trie):
    """Specialized trie that works with tokens from a tokenizer.

    Args:
        tokenizer: The huggingface tokenizer to use for tokenization.

    Attributes:
        tokenizer: The huggingface tokenizer to use for tokenization.
        eos_token_id: The id of the end of sequence token.
        vocab_size: The size of the vocabulary of the tokenizer.
    """

    def __init__(self,
                 tokenizer: PreTrainedTokenizerBase,
                 vocab_size: Optional[int] = None):
        self._id_to_token_map = self._create_id_to_token_map(tokenizer)
        self._token_to_id_map = {
            v: k
            for k, v in self._id_to_token_map.items()
        }

        # TODO (Kourosh): Length of the two maps are not the same, Does this
        # cause any problem? In other words, len(tokenizer_trie) != vocab_size
        super().__init__(self._token_to_id_map)
        self.tokenizer = tokenizer
        self.eos_token_id = self.tokenizer.eos_token_id
        self.vocab_size = vocab_size or len(self.tokenizer)


    def _create_id_to_token_map(
            self, tokenizer: PreTrainedTokenizerBase) -> Dict[int, str]:
        """Helper function to create a mapping from token ids to tokens.

        Some tokenizers (e.g. Llama) have different tokens for sub-words that
        are at the begining of the word or in the middle
        (e.g. `_foo` vs. `foo`). When we are capturing these tokens in the
        trie, we want to make sure the prefixes are correctly captured. In
        order to do this, we use the following trick:

        We prepend a single character token (e.g. `0`) to the start so that
        tokens that start with whitespaces are captured with their whitespaces.
        Then we can remove the first character after decoding so that we get
        the full string representation of the token.
        """
        id_to_token_map = {}
        token_id_for_zero = tokenizer.encode("0")[-1]
        special_tokens = set(tokenizer.all_special_ids)
        for token_idx in range(len(tokenizer)):
            # Special tokens should not be part of the tokenizer trie.
            if token_idx in special_tokens:
                continue
            decode_w_zero = tokenizer.decode([token_id_for_zero,
                                              token_idx])[1:]
            id_to_token_map[token_idx] = decode_w_zero

        return id_to_token_map

    def id2str(self, token_id: int) -> str:
        if token_id in self.tokenizer.all_special_ids:
            return self.tokenizer.decode(token_id)
        if token_id not in self._id_to_token_map:
            raise KeyError(f"Token id {token_id} not found in the trie.")
        return self._id_to_token_map[token_id]
